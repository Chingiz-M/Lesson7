﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj1
{
    public partial class Task1 : Form
    {/*
        Задание: 1. а) Добавить в программу «Удвоитель» подсчет количества отданных команд.
                    б) Добавить меню и команду «Играть». При нажатии появляется сообщение, какое число должен получить игрок.
                    Игрок должен постараться получить это число за минимальное количество ходов.
                    в) * Добавить кнопку «Отменить», которая отменяет последние ходы.
        Фамилия: Орлов
      */
        public int counter = 0;
        public Stack<int> tasks = new Stack<int>();
        public Task1()
        {
            InitializeComponent();
            lblnumber.Text = "1";
        }

        private void узнатьКолвоВведенныхКомандToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this, $"Вы ввели {counter} команд", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnplus_Click(object sender, EventArgs e)
        {
            lblnumber.Text = (int.Parse(lblnumber.Text) + 1).ToString(); 
            tasks.Push(1); // 1 задача
            counter++;
        }

        private void btnmulti_Click(object sender, EventArgs e)
        {
            lblnumber.Text = (int.Parse(lblnumber.Text) * 2).ToString();
            tasks.Push(2); // 2 задача
            counter++;
        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            lblnumber.Text = "1";
            tasks.Clear();
            counter = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(tasks.Count > 0)
            {
                if (tasks.Pop() == 1)
                    lblnumber.Text = (int.Parse(lblnumber.Text) - 1).ToString();
                else
                    lblnumber.Text = (int.Parse(lblnumber.Text) / 2).ToString();
                counter--;
            }
        }
    }
}
