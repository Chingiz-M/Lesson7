﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Proj1
{
    public partial class Task2 : Form
    {/*
        Задание: 2. Используя Windows Forms, разработать игру «Угадай число».
                    Компьютер загадывает число от 1 до 100, а человек пытается его угадать за минимальное число попыток.
                    Для ввода данных от человека используется элемент TextBox.
        Фамилия: Орлов
      */
        public int randomnum = -1;
        Random random = new Random();
        int counter = 0;
        public Task2()
        {
            InitializeComponent();
            randomnum = random.Next(1,100);
        }

        private void btngo_Click(object sender, EventArgs e)
        {
            lblresult.ForeColor = Color.OrangeRed;

            if (txtinput.Text != "")
            {
                if(int.TryParse(txtinput.Text,out int num))
                {
                    if(num >= 1 && num <= 100)
                    {
                        counter++;
                        if(num > randomnum)
                            lblresult.Text = "Ваше число больше заданного!";
                        if(num < randomnum)
                            lblresult.Text = "Ваше число меньше заданного!";
                        if(num == randomnum)
                        {
                            lblresult.ForeColor = Color.Green;
                            lblresult.Text = $"Поздравляю, вы угадали число за {counter} попыток!\n Я загадал новое число, попробуй угадать!";
                            randomnum = random.Next(1, 100);
                            counter = 0;
                        }
                    }
                    else
                        lblresult.Text = "Вы ввели число вне диапазона!";
                }
                else
                    lblresult.Text = "Вы ввели не число!";
            }
            else
                lblresult.Text = "Введите число!";
        }

        private void Task2_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show(this, $"Загаданное число: {randomnum}", "Уведомление", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
