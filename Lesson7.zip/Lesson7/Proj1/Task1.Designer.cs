﻿namespace Proj1
{
    partial class Task1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Task1));
            this.btnplus = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.игратьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.узнатьКолвоВведенныхКомандToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnmulti = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.lblnumber = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnplus
            // 
            this.btnplus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnplus.Location = new System.Drawing.Point(239, 59);
            this.btnplus.Name = "btnplus";
            this.btnplus.Size = new System.Drawing.Size(74, 30);
            this.btnplus.TabIndex = 0;
            this.btnplus.Text = "+1";
            this.btnplus.UseVisualStyleBackColor = true;
            this.btnplus.Click += new System.EventHandler(this.btnplus_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Число:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.игратьToolStripMenuItem,
            this.узнатьКолвоВведенныхКомандToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(368, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // игратьToolStripMenuItem
            // 
            this.игратьToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("игратьToolStripMenuItem.Image")));
            this.игратьToolStripMenuItem.Name = "игратьToolStripMenuItem";
            this.игратьToolStripMenuItem.Size = new System.Drawing.Size(91, 24);
            this.игратьToolStripMenuItem.Text = "Играть";
            // 
            // узнатьКолвоВведенныхКомандToolStripMenuItem
            // 
            this.узнатьКолвоВведенныхКомандToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("узнатьКолвоВведенныхКомандToolStripMenuItem.Image")));
            this.узнатьКолвоВведенныхКомандToolStripMenuItem.Name = "узнатьКолвоВведенныхКомандToolStripMenuItem";
            this.узнатьКолвоВведенныхКомандToolStripMenuItem.Size = new System.Drawing.Size(228, 24);
            this.узнатьКолвоВведенныхКомандToolStripMenuItem.Text = "Кол-во введённых команд";
            this.узнатьКолвоВведенныхКомандToolStripMenuItem.Click += new System.EventHandler(this.узнатьКолвоВведенныхКомандToolStripMenuItem_Click);
            // 
            // btnmulti
            // 
            this.btnmulti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmulti.Location = new System.Drawing.Point(239, 115);
            this.btnmulti.Name = "btnmulti";
            this.btnmulti.Size = new System.Drawing.Size(74, 30);
            this.btnmulti.TabIndex = 5;
            this.btnmulti.Text = "x2";
            this.btnmulti.UseVisualStyleBackColor = true;
            this.btnmulti.Click += new System.EventHandler(this.btnmulti_Click);
            // 
            // btnreset
            // 
            this.btnreset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnreset.Location = new System.Drawing.Point(125, 115);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(93, 30);
            this.btnreset.TabIndex = 6;
            this.btnreset.Text = "Сброс";
            this.btnreset.UseVisualStyleBackColor = true;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Location = new System.Drawing.Point(15, 115);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(93, 30);
            this.button4.TabIndex = 7;
            this.button4.Text = "Отменить";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // lblnumber
            // 
            this.lblnumber.AutoSize = true;
            this.lblnumber.Location = new System.Drawing.Point(122, 59);
            this.lblnumber.Name = "lblnumber";
            this.lblnumber.Size = new System.Drawing.Size(0, 17);
            this.lblnumber.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 176);
            this.Controls.Add(this.lblnumber);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btnmulti);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnplus);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(386, 223);
            this.MinimumSize = new System.Drawing.Size(386, 223);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Удвоитель";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnplus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem игратьToolStripMenuItem;
        private System.Windows.Forms.Button btnmulti;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ToolStripMenuItem узнатьКолвоВведенныхКомандToolStripMenuItem;
        private System.Windows.Forms.Label lblnumber;
    }
}

